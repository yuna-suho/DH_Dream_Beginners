#!/usr/bin/env python3
import os
import pymysql
from flask import Flask, abort, redirect, render_template, request

PAGINATION_SIZE = 10

app = Flask(__name__)
app.secret_key = os.urandom(32)

def connect_mysql():
    conn = pymysql.connect(host='db',
                           port=3306,
                           user=os.environ['MYSQL_USER'],
                           passwd=os.environ['MYSQL_PASSWORD'],
                           db='board',
                           charset='utf8mb4')
    cursor = conn.cursor()
    return conn, cursor

@app.route('/')
def index():
    return redirect('/board')

@app.route('/board')
def board():

    page = request.args.get('page')
    page = int(page) if page and page.isdigit() and int(page) > 0 else 1

    ret = []

    conn, cursor = connect_mysql()
    try:
        query = 'SELECT _id, title FROM posts ORDER BY _id DESC LIMIT %s, %s'
        cursor.execute(query, ((page - 1) * PAGINATION_SIZE, PAGINATION_SIZE))
        ret = cursor.fetchall()
    except Exception as e:
        print(e, flush=True)
        abort(400)
    finally:
        cursor.close()
        conn.close()

    return render_template('board.html', page=page, ret=ret)

@app.route('/board/<post_id>')
def board_post(post_id):

    if not post_id or not post_id.isdigit() or int(post_id) < 1:
        abort(400)

    ret = None

    conn, cursor = connect_mysql()
    try:
        query = 'SELECT title, content FROM posts WHERE _id = %s'
        cursor.execute(query, (post_id))
        ret = cursor.fetchone()
    except Exception as e:
        print(e, flush=True)
        abort(400)
    finally:
        cursor.close()
        conn.close()

    if not ret:
        abort(404)

    return render_template('post.html', title=ret[0],
                           content=ret[1], post_id=post_id)

@app.route('/write_post', methods=['POST'])
def write_post():
    if 'title' not in request.form or 'content' not in request.form:
        return render_template('write_post.html')

    title = request.form['title']
    content = request.form['content']

    conn, cursor = connect_mysql()
    try:
        query = 'INSERT INTO posts (title, content) VALUES (%s, %s)'
        cursor.execute(query, (title, content))
        conn.commit()
    except Exception as e:
        print(e, flush=True)
        abort(400)
    finally:
        cursor.close()
        conn.close()

    return redirect('/board')

@app.route('/modify_post', methods=['POST'])
def modify_post():
    post_id = request.form['post_id']

    if not post_id or not post_id.isdigit() or int(post_id) < 1:
        abort(400)

    if 'title' not in request.form or 'content' not in request.form:
        conn, cursor = connect_mysql()
        try:
            query = 'SELECT title, content FROM posts WHERE _id = %s'
            cursor.execute(query, (post_id, ))
            ret = cursor.fetchone()
        except Exception as e:
            print(e, flush=True)
            abort(400)
        finally:
            cursor.close()
            conn.close()

        if not ret:
            abort(404)

        return render_template('modify_post.html', title=ret[0],
                               content=ret[1], post_id=post_id)

    title = request.form['title']
    content = request.form['content']

    conn, cursor = connect_mysql()
    try:
        query = 'UPDATE posts SET title=%s, content=%s WHERE _id = %s'
        cursor.execute(query, (title, content, post_id, ))
        conn.commit()
    except Exception as e:
        print(e, flush=True)
    finally:
        cursor.close()
        conn.close()

    return redirect(f'/board/{post_id}')

@app.route('/delete_post', methods=['POST'])
def delete_post():

    post_id = request.form['post_id']
    if not post_id or not post_id.isdigit() or int(post_id) < 1:
        abort(400)

    if 'answer' not in request.form:
        return render_template('delete_post.html', post_id=post_id)

    if request.form['answer'] == 'y':
        conn, cursor = connect_mysql()
        try:
            query = 'DELETE FROM posts WHERE _id = %s'
            cursor.execute(query, (post_id, ))
            conn.commit()
        except Exception as e:
            print(e, flush=True)
        finally:
            cursor.close()
            conn.close()

        return redirect('/board')

    return redirect(f'/board/{post_id}')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)
