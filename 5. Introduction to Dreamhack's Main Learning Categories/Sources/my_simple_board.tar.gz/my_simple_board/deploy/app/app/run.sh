#!/bin/sh

export MYSQL_USER=dbuser
export MYSQL_PASSWORD=dbpass

sleep 1

python3 app.py