CREATE USER 'dbuser'@'%' IDENTIFIED BY 'dbpass';

CREATE DATABASE board;

GRANT ALL PRIVILEGES ON board.* TO 'dbuser'@'%';

USE `board`;

CREATE TABLE `posts` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `content` varchar(4096) NOT NULL,
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

INSERT INTO posts (title, content) VALUES ('My First Post', 'blah blah ~');
